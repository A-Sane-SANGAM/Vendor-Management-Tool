from django.urls import path
from vmtApp import views
from django.conf.urls import include, url
from django.contrib import admin



'''This code imports the views from our vmtApp
and expects a view called homePageView '''
urlpatterns = [
    path('',views.indexPageView.as_view()),
    path('home/',views.homePageView.as_view(),name='home'),
    path('home/dataUpload/',views.dataUploadView.as_view(),name='dataUpload'),
    url(r'^upload/', views.upload, name="upload"),
    path('home/qualityCheckStatus/',views.qualityCheckView.as_view(),name='qualityCheck'),
    path('home/tracker/',views.trackerView.as_view(),name='tracker'),
    path('forgotPassword/',views.forgotPasswordView.as_view(),name='forgotPassword'),
    path('userProfile/',views.userProfileView.as_view(),name='userProfile'),
    path('logout/',views.logoutView.as_view(),name='logout'), 
    
]


# path('home/',views.homePageView.as_view(),name='home'),
