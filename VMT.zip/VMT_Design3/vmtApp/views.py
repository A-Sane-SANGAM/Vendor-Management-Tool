from django.shortcuts import render
from django.views.generic import TemplateView
from django.http import HttpResponse
import os
from django.utils.datastructures import MultiValueDictKeyError



'''	Defining a view called homePageView.It takes in a request and returns a response.
	Request is of 'GET' type and it renders a template called index.html
	Since passed arguement is TemplateView therefore it looks into 'templates' folder inside the app for the index file. '''
class indexPageView(TemplateView):
	def get(self,request,**kwargs):
		return render(request,'index.html',context=None)

class homePageView(TemplateView):
	template_name="home.html"

class forgotPasswordView(TemplateView):
	template_name="forgotPassword.html"

class logoutView(TemplateView):
	template_name="logout.html"

class userProfileView(TemplateView):
	template_name="userProfile.html"

class dataUploadView(TemplateView):
	template_name="dataUpload.html"

def upload(request):
	try:
		fileUpload = request.FILES['file']
		# print(fileUp.name)
		# print(fileUp.size)
		nameVars = fileUpload.name.split('.')
		extension = nameVars[1]
		size = fileUpload.size /(1024*1024)
		if request.method == 'POST' and extension == 'xlsx' and size <= 2:
			handle_uploaded_file(request.FILES['file'], str(request.FILES['file']))
			return render(request,'dataUpload.html',{'uploadMessage' :'<img src="/static/media/success.png"> <br>Successfully Uploaded!!','instruction':"$('#messageModal').modal('toggle');"}) #HttpResponse("Successful")
			
		return render(request,'dataUpload.html',{'uploadMessage' :'<img src="/static/media/error.png"> <br> Error: Choose another File!!','instruction':"$('#messageModal').modal('toggle');"})#HttpResponse("Failed")
	except MultiValueDictKeyError:
		return render(request,'dataUpload.html',{'uploadMessage' :'<img src="/static/media/warning.png"> <br> Choose File First!!','instruction':"$('#messageModal').modal('toggle');"})
		
def handle_uploaded_file(file, filename):
    if not os.path.exists('upload/'):
        os.mkdir('upload/')
 
    with open('upload/' + filename, 'wb+') as destination:
        for chunk in file.chunks():
            destination.write(chunk)


class qualityCheckView(TemplateView):
	template_name="qualityCheckStatus.html"

class trackerView(TemplateView):
	template_name="tracker.html"

