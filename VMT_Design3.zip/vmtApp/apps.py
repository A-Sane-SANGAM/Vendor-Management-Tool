from django.apps import AppConfig


class VmtappConfig(AppConfig):
    name = 'vmtApp'
